from panda_gym.envs.panda_tasks.panda_cubes import PandaCubes
from panda_gym.envs.panda_tasks.panda_rope import PandaRope
from panda_gym.envs.panda_tasks.panda_clean_plate import PandaCleanPlate
from panda_gym.envs.panda_tasks.panda_sponge import PandaSponge
from panda_gym.envs.panda_tasks.panda_move_table import PandaMoveTable
